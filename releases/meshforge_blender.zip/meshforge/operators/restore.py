"""MeshForge - Opérateur de restauration et de bascule de prévisualisation."""

from __future__ import annotations
import bpy


class MESHFORGE_OT_restore(bpy.types.Operator):
    """Supprime l'objet optimisé et réactive l'objet maillage d'origine"""
    bl_idname = "meshforge.restore"
    bl_label = "Restaurer / Supprimer le résultat"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            obj is not None and
            "_MF_Optimized" in obj.name and
            context.mode == 'OBJECT' and
            obj.mode == 'OBJECT'
        )

    def execute(self, context):
        current_obj = context.active_object
        if context.mode != 'OBJECT' or (current_obj and current_obj.mode != 'OBJECT'):
            self.report({'WARNING'}, "MeshForge : La restauration requiert le mode Objet. Veuillez repasser en mode Objet (Touche Tab).")
            return {'CANCELLED'}

        has_ptr = ("_mf_source_ptr" in current_obj)
        orig_obj = current_obj.get("_mf_source_ptr")

        if has_ptr and orig_obj is None:
            # L'objet référencé initialement a été détruit : refuser de binder sur un éventuel objet homonyme récent
            self.report(
                {'WARNING'},
                "MeshForge : L'objet source original a été supprimé de la scène. "
                "Le résultat optimisé est conservé pour éviter toute perte de géométrie."
            )
            return {'CANCELLED'}

        if not orig_obj or orig_obj.name not in bpy.data.objects:
            orig_name = current_obj.get("_mf_source_object", "")
            if not orig_name or orig_name not in bpy.data.objects:
                orig_name = current_obj.name.split("_MF_Optimized")[0]
            orig_obj = bpy.data.objects.get(orig_name)
        else:
            orig_name = orig_obj.name

        if not orig_obj or orig_obj.name not in bpy.data.objects:
            self.report(
                {'WARNING'},
                f"MeshForge : L'objet source original ('{orig_name}') est introuvable (supprimé). "
                "Le résultat optimisé est conservé pour éviter toute perte de géométrie."
            )
            return {'CANCELLED'}

        # Retrouver et restaurer l'objet original (avec garde-fou de vue/scène)
        orig_obj.hide_set(False)
        if orig_obj.name in context.view_layer.objects:
            context.view_layer.objects.active = orig_obj
            orig_obj.select_set(True)

        # Supprimer le résultat courant
        mesh_to_delete = current_obj.data
        bpy.data.objects.remove(current_obj, do_unlink=True)
        if mesh_to_delete and mesh_to_delete.users == 0:
            bpy.data.meshes.remove(mesh_to_delete)

        self.report({'INFO'}, f"Résultat supprimé, objet original '{orig_name}' restauré.")
        return {'FINISHED'}


# Mémorisation des objets dont le mode filaire a été activé par MeshForge
# Associe obj.name -> (prior_show_wire, prior_show_all_edges)
_WIREFRAME_ENABLED_BY_MESHFORGE: dict[str, tuple[bool, bool]] = {}


def restore_wireframe_if_meshforge_enabled(obj: bpy.types.Object) -> bool:
    """Restaure l'état d'affichage filaire initial si MeshForge l'avait modifié."""
    if not obj or obj.name not in _WIREFRAME_ENABLED_BY_MESHFORGE:
        return False
    prior_wire, prior_all_edges = _WIREFRAME_ENABLED_BY_MESHFORGE.pop(obj.name)
    obj.show_wire = prior_wire
    obj.show_all_edges = prior_all_edges
    return True


class MESHFORGE_OT_toggle_wireframe(bpy.types.Operator):
    """Bascule l'affichage filaire (Wireframe) pour inspecter la topologie"""
    bl_idname = "meshforge.toggle_wireframe"
    bl_label = "Affichage Filaire"
    bl_description = "Bascule l'affichage filaire de l'objet pour visualiser les boucles d'arêtes et la topologie"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None and
            context.active_object.type == 'MESH'
        )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        is_currently_on = getattr(obj, "show_wire", False)
        if is_currently_on:
            # Désactiver le filaire et restaurer l'état préexistant
            if obj.name in _WIREFRAME_ENABLED_BY_MESHFORGE:
                prior_wire, prior_all_edges = _WIREFRAME_ENABLED_BY_MESHFORGE.pop(obj.name)
                obj.show_wire = prior_wire
                obj.show_all_edges = prior_all_edges
            else:
                obj.show_wire = False
                obj.show_all_edges = False
            self.report({'INFO'}, "MeshForge : Affichage filaire désactivé.")
        else:
            # Activer le filaire et mémoriser l'état initial
            if obj.name not in _WIREFRAME_ENABLED_BY_MESHFORGE:
                _WIREFRAME_ENABLED_BY_MESHFORGE[obj.name] = (obj.show_wire, obj.show_all_edges)
            obj.show_wire = True
            obj.show_all_edges = True
            self.report({'INFO'}, "MeshForge : Affichage filaire activé.")

        return {'FINISHED'}
