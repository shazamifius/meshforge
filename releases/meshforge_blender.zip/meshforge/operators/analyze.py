"""MeshForge - Opérateur d'analyse et diagnostic initial (lecture seule)."""

from __future__ import annotations
import bpy
from ..core.mesh_stats import get_mesh_statistics
from ..core.topology_diagnosis import diagnose_topology
from .topology_inspect import _ACTIVE_DIAGNOSIS_CACHE


class MESHFORGE_OT_analyze(bpy.types.Operator):
    """Analyse l'état topologique et géométrique du maillage actif sans le modifier"""
    bl_idname = "meshforge.analyze"
    bl_label = "Analyser seulement"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            obj is not None and
            obj.type == 'MESH' and
            context.mode == 'OBJECT' and
            obj.mode == 'OBJECT'
        )

    def execute(self, context):
        obj = context.active_object
        if context.mode != 'OBJECT' or (obj and obj.mode != 'OBJECT'):
            self.report({'WARNING'}, "MeshForge : L'analyse requiert le mode Objet. Veuillez repasser en mode Objet (Touche Tab).")
            return {'CANCELLED'}

        props = context.scene.meshforge_settings

        stats = get_mesh_statistics(obj)
        if not stats.get("valid", False):
            self.report({'ERROR'}, stats.get("error", "Erreur lors de l'analyse."))
            return {'CANCELLED'}

        # Diagnostic topologique non-destructif pour l'assistant
        diag = diagnose_topology(obj, mode=props.asset_target_mode)
        _ACTIVE_DIAGNOSIS_CACHE[obj.name] = diag

        # Mise à jour des propriétés d'affichage
        props.last_status = "Analysé"
        props.last_duration = 0.0
        props.last_result_obj_name = obj.name
        props.last_verts_before = stats["vertices"]
        props.last_verts_after = stats["vertices"]
        props.last_edges_before = stats["edges"]
        props.last_edges_after = stats["edges"]
        props.last_faces_before = stats["faces"]
        props.last_faces_after = stats["faces"]
        props.last_tris_before = stats["estimated_triangles"]
        props.last_tris_after = stats["estimated_triangles"]
        props.last_reduction = 0.0

        summary = (
            f"Triangles: {stats['estimated_triangles']} | Faces: {stats['faces']} "
            f"(Tris: {stats['tri_faces']}, Quads: {stats['quad_faces']}, N-gons: {stats['ngon_faces']})\n"
            f"Non-Manifold Edges: {stats['non_manifold_edges']}, Verts: {stats['non_manifold_verts']}\n"
            f"Frontières: {stats['boundary_edges']}, Éléments lâches: {stats['loose_verts']}V/{stats['loose_edges']}E\n"
            f"Faces d'aire nulle: {stats['zero_area_faces']}, UVs: {stats['uv_layer_count']}, Matériaux: {stats['material_slot_count']}"
        )
        props.last_logs = summary

        self.report({'INFO'}, f"Analyse MeshForge : {stats['faces']} faces, {stats['estimated_triangles']} triangles.")
        return {'FINISHED'}
